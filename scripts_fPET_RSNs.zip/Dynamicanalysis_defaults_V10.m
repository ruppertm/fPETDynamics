function [wdir, outdir] = Dynamicanalysis_defaults_V10
    % Dynamicanalysis_defaults_V2: Definiert Standardverzeichnisse für das Projekt.

    close all; clear; clc;

    if ispc
        % Windows-Pfade
        wdir = 'L:\Lenna\Versuch_2\scans';                    % Arbeitsverzeichnis
        outdir = 'L:\Lenna\Versuch_10\output';                 % Output-Verzeichnis
        addpath(genpath('L:\Lenna\Versuch_10\scripts'));       % Scripts hinzufügen
        addpath('C:\Program Files\MATLAB\R2023a');            % SPM-Pfad
    elseif isunix
        % Unix-Pfade
        wdir = '/home/user/Versuch_2/scans';
        outdir = '/home/user/Versuch_10/output';
        addpath(genpath('/home/user/Versuch_10/Scripts'));
        addpath('~/spm12/'); % Pfad zu SPM
    else
        error('Betriebssystem nicht erkannt. Bitte Pfade manuell anpassen.');
    end
end
