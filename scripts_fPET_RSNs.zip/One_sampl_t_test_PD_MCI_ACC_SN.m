% One-Sample-T-Test für PD_MCI-Z-Maps
% Author L. Rüsing, adpted from K.Steidel, University Hospital of Gießen and Marburg
% Dieses Skript testet, ob die mittlere Z-Map-Werte der PD_MCI signifikant von 0 abweichen.

clear; clc;

% Setze das Arbeitsverzeichnis (Passe `outdir` an dein Verzeichnis an)
[wdir, outdir] = Dynamicanalysis_defaults_V10;

% Definiere den Speicherort für den Test
one_sample_outputdir = fullfile(outdir, 'One_Sample_T_test_for_PD_MCI_ACC_SN_Con');

% Stelle sicher, dass das Ausgabeverzeichnis existiert
if ~exist(one_sample_outputdir, 'dir')
    mkdir(one_sample_outputdir);
end

% Lade alle Z-Maps der PD_MCI
allconmapPdMCI =  {
    fullfile(outdir, 'Subjects_ACC_SN', 'first_level_003', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_ACC_SN', 'first_level_005', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_ACC_SN', 'first_level_010', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_ACC_SN', 'first_level_014', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_ACC_SN', 'first_level_025', 'con_0001.nii'),
};

% Führe den One-Sample-T-Test durch
perform_one_sample_t_test(allconmapPdMCI, one_sample_outputdir);

% Ergebnisse anzeigen
showresults(one_sample_outputdir);

disp('One-Sample-T-Test für PD_MCI abgeschlossen.');
