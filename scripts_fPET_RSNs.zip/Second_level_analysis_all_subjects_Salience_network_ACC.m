
%%% Dynamic voxel-wise second-level analysis
% Author L. Rüsing, adpted from K.Steidel, University Hospital of Gießen and Marburg
% General Settings
[wdir, outdir] = Dynamicanalysis_defaults_V10;


% General Settings to define new folders: subj = [first_level_pat... first_level_con...];
% Zweck: Die T-Maps aus der First-Level-Analyse  werden in Z-Maps umgewandelt, um statistische Vergleiche zwischen Gruppen zu ermöglichen.
firstlevelPDMCI = {'first_level_003', 'first_level_005', 'first_level_010', 'first_level_014', 'first_level_025'};
firstlevelPdNC = {'first_level_001', 'first_level_002', 'first_level_007', 'first_level_008', 'first_level_016', 'first_level_022', 'first_level_026', 'first_level_028', 'first_level_029'};

% Loop through folders for T-maps of patients --> Umwandlung jeder T-Map in eine Z-Map und Speicherung im Ordner all_z_maps_PdMCI
for i = 1:length(firstlevelPDMCI)
    % Bestimmen des Pfads zur T-Map des aktuellen Patienten
    subjdirPDMCI = fullfile(outdir, 'Subjects_ACC_SN', firstlevelPDMCI{i}, 'spmT_0001');
    
    % Prüfen, ob die T-Map existiert, um Fehler zu vermeiden
    if ~exist([subjdirPDMCI '.nii'], 'file')
        % Falls die Datei nicht existiert, wird eine Warnung ausgegeben und die Iteration übersprungen
        warning('Die Datei %s existiert nicht. Überspringe diese Iteration.', subjdirPDMCI);
        continue;
    end
    
    % Bestimmen des Ausgabeordners für die Z-Map des aktuellen Patienten
    outoutdirPDMCI = fullfile(outdir, 'Subjects_ACC_SN', 'all_z_maps_PdMCI', ['spmZ_' firstlevelPDMCI{i}]);

    % Überprüfe, ob das Ausgabeverzeichnis existiert, andernfalls erstelle es
    if ~exist(outoutdirPDMCI, 'dir')
        mkdir(outoutdirPDMCI);  % Erstellt das Verzeichnis, wenn es nicht existiert
    end

    % Konvertiere T-Maps von Patienten in Z-Maps für den Zweigruppen-t-Test
    % Die Funktion convert_spm_stat wird verwendet, um die T-Maps in Z-Maps umzuwandeln
    % Der dritte Parameter gibt den Freiheitsgrad (dof) an (z.B. 7 für eine typische Analyse)
    convert_spm_stat('TtoZ', subjdirPDMCI, outoutdirPDMCI, '7');
end

% Loop through folders for T-maps of controls --> Umwandlung jeder T-Map in eine Z-Map und Speicherung im Ordner all_z_maps_PdNC
for i = 1:length(firstlevelPdNC)
    % Bestimmen des Pfads zur T-Map der aktuellen Kontrolle
    subjdirPdNc = fullfile(outdir, 'Subjects_ACC_SN', firstlevelPdNC{i}, 'spmT_0001');
    
    % Prüfen, ob die T-Map existiert, um Fehler zu vermeiden
    if ~exist([subjdirPdNc '.nii'], 'file')
        % Falls die Datei nicht existiert, wird eine Warnung ausgegeben und die Iteration übersprungen
        warning('Die Datei %s existiert nicht. Überspringe diese Iteration.', subjdirPdNc);
        continue;
    end
    
    % Bestimmen des Ausgabeordners für die Z-Map der aktuellen Kontrolle
    outputdirPdNc = fullfile(outdir, 'Subjects_ACC_SN', 'all_z_maps_PdNC', ['spmZ_' firstlevelPdNC{i}]);

    % Überprüfe, ob das Ausgabeverzeichnis existiert, andernfalls erstelle es
    if ~exist(outputdirPdNc, 'dir')
        mkdir(outputdirPdNc);  % Erstellt das Verzeichnis, wenn es nicht existiert
    end

    % Konvertiere T-Maps von Kontrollen in Z-Maps für den Zweigruppen-t-Test
    % Die Funktion convert_spm_stat wird verwendet, um die T-Maps in Z-Maps umzuwandeln
    % Der dritte Parameter gibt den Freiheitsgrad (dof) an (z.B. 7 für eine typische Analyse)
    convert_spm_stat('TtoZ', subjdirPdNc, outputdirPdNc, '7');
end


% Two- sample- t_test for Z-maps of patients (group 1) and controls (group 2) 
% Ziel: Vergleich der Z-Maps von Patienten- und Kontrollgruppe, um Unterschiede in der Hirnaktivität zu identifizieren.

lastoutputdir = fullfile(outdir, 'T_test_for_Z-maps_ACC_SN_Con');

% Con-Maps der PdMCI (Gruppe 1) - Ordnerstruktur für Patienten anpassen
allconmapsPdMCI = {
    fullfile(outdir, 'Subjects_ACC_SN', 'first_level_003', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_ACC_SN', 'first_level_005', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_ACC_SN', 'first_level_010', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_ACC_SN', 'first_level_014', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_ACC_SN', 'first_level_025', 'con_0001.nii'),
};

% Con-Maps der PdNc (Gruppe 2) - Ordnerstruktur für Kontrollen anpassen
allconmapsPdNc = {
    fullfile(outdir, 'Subjects_ACC_SN', 'first_level_001', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_ACC_SN', 'first_level_002', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_ACC_SN', 'first_level_007', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_ACC_SN', 'first_level_008', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_ACC_SN', 'first_level_016', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_ACC_SN', 'first_level_022', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_ACC_SN', 'first_level_026', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_ACC_SN', 'first_level_028', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_ACC_SN', 'first_level_029', 'con_0001.nii'),
};

perform_two_sample_t_test(allconmapsPdMCI, allconmapsPdNc, [-1 1], lastoutputdir)

showresults(lastoutputdir)