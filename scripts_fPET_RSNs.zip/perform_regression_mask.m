function perform_regression_mask(group_files, covariate, mask, contrast, output_dir)
% This function performs a voxel-wise Multiple regression using SPM12..
%
% Inputs:
% - group_files: a cell array of file paths for scans
% - covariate: a numeric array of the covariate
% - contrast: a vector of length 2 specifying the contrast for the t-test
% - output_dir: a string specifying the directory to save the output
%
% The contrast is used to set the weights for the Mutiple regression.
% Usually should be [0 1].
%
    % Check inputs
    assert(iscell(group_files), 'group1_files must be a cell array of file paths');
    assert(isnumeric(covariate), 'covariate must be an array of numerican values');
    assert(ischar(mask), 'mask must be a string');
    assert(isvector(contrast) && length(contrast) == 2, 'contrast must be a vector of length 2');
    assert(ischar(output_dir), 'output_dir must be a string');

    % Initialize SPM
    spm('defaults', 'PET');
    spm_jobman('initcfg');
   
    % specify output directory
    matlabbatch{1}.spm.stats.factorial_design.dir = {output_dir};
   
    % Set up the design matrix for a two-sample t-test
    matlabbatch{1}.spm.stats.factorial_design.des.mreg.scans = group_files;
    matlabbatch{1}.spm.stats.factorial_design.des.mreg.mcov = struct('c', {}, 'cname', {}, 'iCC', {});
    matlabbatch{1}.spm.stats.factorial_design.des.mreg.incint = 1;
    matlabbatch{1}.spm.stats.factorial_design.cov.c = covariate(:);
    matlabbatch{1}.spm.stats.factorial_design.cov.cname = 'SN';
    matlabbatch{1}.spm.stats.factorial_design.cov.iCFI = 1;
    matlabbatch{1}.spm.stats.factorial_design.cov.iCC = 1;
    matlabbatch{1}.spm.stats.factorial_design.multi_cov = struct('files', {}, 'iCFI', {}, 'iCC', {});
    matlabbatch{1}.spm.stats.factorial_design.masking.tm.tm_none = 1;
    matlabbatch{1}.spm.stats.factorial_design.masking.im = 1;
    matlabbatch{1}.spm.stats.factorial_design.masking.em = {mask};
    matlabbatch{1}.spm.stats.factorial_design.globalc.g_omit = 1;
    matlabbatch{1}.spm.stats.factorial_design.globalm.gmsca.gmsca_no = 1;
    matlabbatch{1}.spm.stats.factorial_design.globalm.glonorm = 1;
    
   
    % Estimate the model
    matlabbatch{2}.spm.stats.fmri_est.spmmat = {fullfile(output_dir, 'SPM.mat')};

    % Set up the contrast for the t-test
    matlabbatch{3}.spm.stats.con.spmmat = {fullfile(output_dir, 'SPM.mat')};
    matlabbatch{3}.spm.stats.con.consess{1}.tcon.name = 'Mreg';
    matlabbatch{3}.spm.stats.con.consess{1}.tcon.weights = contrast;
    matlabbatch{3}.spm.stats.con.consess{1}.tcon.sessrep = 'none';

    % Run the job
    spm_jobman('run', matlabbatch);
end
