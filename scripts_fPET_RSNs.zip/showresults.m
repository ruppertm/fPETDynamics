function showresults(matdir, roi_file)
% SHOWRESULTS Displays the results of an estimated SPM job and optionally
% performs small volume correction (SVC).
%
% Usage:
%   showresults(matdir)
%   showresults(matdir, roi_file)
%
% Inputs:
%   matdir   - A string specifying the directory containing the SPM.mat file.
%   roi_file - (Optional) A string specifying the full file path of a binary
%              mask in nifti file format. If provided, SVC will be performed
%              using this mask. If not provided or empty, no SVC will be
%              performed.
%
% Outputs:
%   The function displays the results in SPM's graphical interface and
%   exports them as a postscript file. It also outputs a message indicating
%   whether SVC was performed.
%
% Notes:
%   Ensure that SPM is added to the MATLAB path before using this function.

% Initialize SPM and job manager
spm('defaults','pet');
spm_jobman('initcfg');

% Setup batch job structure
results = struct;
results.matlabbatch{1}.spm.stats.results.spmmat = {[matdir filesep 'SPM.mat']};

% Contrast specification
results.matlabbatch{1}.spm.stats.results.conspec.titlestr = '';
results.matlabbatch{1}.spm.stats.results.conspec.contrasts = 1;
results.matlabbatch{1}.spm.stats.results.conspec.threshdesc = 'none';
results.matlabbatch{1}.spm.stats.results.conspec.thresh = 0.001;
results.matlabbatch{1}.spm.stats.results.conspec.extent = 0;
results.matlabbatch{1}.spm.stats.results.conspec.conjunction = 1;

% Check if roi_file is provided for SVC
if nargin > 1 && ~isempty(roi_file)
    results.matlabbatch{1}.spm.stats.results.conspec.mask.image = {roi_file};
    results.matlabbatch{1}.spm.stats.results.conspec.mask.threshold = 0.5;
    fprintf('Small Volume Correction (SVC) will be performed using the provided ROI mask.\n');
else
    results.matlabbatch{1}.spm.stats.results.conspec.mask.none = 1;
    fprintf('No ROI mask provided. Small Volume Correction (SVC) will not be performed.\n');
end

% Specify units and export settings
results.matlabbatch{1}.spm.stats.results.units = 1;
results.matlabbatch{1}.spm.stats.results.export{1}.ps = 1;

% Run the batch job
spm_jobman('run',results.matlabbatch);
end