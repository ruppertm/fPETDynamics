%% Dynamic voxel-wise analysis for SN_R, SN_L, or SN_BIL
% Author L. Rüsing, adpted from K.Steidel, University Hospital of Gießen and Marburg
% First-level analysis
% Ziel:  die Gehirnaktivität in spezifischen Regionen --> ROI (z. B. SN) auf Subjektebene zu untersuchen und dabei die Korrelation zu anderen Hirnregionen analysieren.
% General Settings to define subjects and ROI
[wdir, outdir] = Dynamicanalysis_defaults_V7; % Seitenskript in dem der Hauptarbeitsordner und der Ausgabeordner festgelegt werden

% Liste aller Subjects
subj = {'001', '002', '003', '005', '004', '006', '007', '008', '010', '011', ...
        '012', '014', '015', '016', '017', '018', '019', '020', '021', '022', ...
        '023', '024', '025', '026', '027', '028', '029'};

% ROI-Datei definieren (z. B. SN_R,al) --> um spezifische Hirnregion zu anlysieren
roi = 'L:\Lenna\Versuch_7\Rois\HC_gr_PD_fwe_SNL.nii';

% ICV-Maske definieren um Hirnbereiche für die Analyse einzugrenzen bzw. auszuschließen. 
% In disem Fall Begrenzt die Maske die Analyse auf das gesamte Gehirn und stellt sicher, dass nur Hirnbereiche berücksichtigt werden.
% Die Maske ermöglicht, dass die Aktivität der ROI mit der Aktivität im restlichen Gehirn (innerhalb der Maske) verglichen werden kann.
mas = fullfile('L:\Lenna\Versuch_7\masks\combinde_mask_subCort_nigrost.nii');

% Schleife durch alle Subjects
for i = 1:length(subj)
    % Arbeits- und Output-Pfade definieren
    subjdir = fullfile(wdir, 'Subjects_norm', subj{i});  % Verwendet normalisierte Daten aus der Intensitätsnormalisierung (Siehe Skript Intensity normalization). 
    outputdir = fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', ['first_level_' subj{i}]);
    
    % Output-Ordner erstellen, falls er nicht existiert
    if ~exist(outputdir, 'dir')
        mkdir(outputdir);
    end
    
    % NIfTI-Dateien des Subjects abrufen (nur normalisierte Dateien)
    scans = get_subject_filepaths(subjdir, '_GMnorm'); % Nur Dateien mit "_GMnorm"
    
    % Überprüfen, ob Scans existieren
    if isempty(scans)
        warning(['Keine normalisierten Scans gefunden für Subject: ', subj{i}]);
        continue;
    end
    
    % ROI-Daten extrahieren --> Für jedes Subjekt werden aus den Gehirnscans die Daten innerhalb der ROI extrahiert. Diese werden als Kovariate verwendet.
    cov = extract_roi_data(scans, roi);
    
    % Regression mit Maske durchführen --> Die Beziehung zwischen den lokalen Aktivitätsmustern in der ROI (cov) und der globalen Hirnaktivität (scans)  modellieren.
    perform_regression_mask(scans, cov, mas, [0 1], outputdir);
    
    % Ergebnisse anzeigen
    showresults(outputdir);
end

disp('First-level analysis für alle Subjects abgeschlossen.');