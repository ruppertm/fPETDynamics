% Intensity normalization of FDOPA PET Data with occipital reference
% region using SPM's ImCalc function 

%   Copyright (C) July 2021
%   K.Steidel, University Hospital of Gie�en and Marburg, adapted by L. R�sing
%
%   This software may be used, copied, or redistributed as long as it is
%   not sold and this copyright notice is reproduced on each copy made.
%   This routine is provided as is without any express or implied
%   warranties whatsoever.

clear;clc; % clear workspace and command window


% define the folder where the scans are
%folder �ndern, nur eine Gruppe Subjects
myFolder1='D:\Lenna\Versuch_1\scans\Subjects\001';
 

for adap=1:2
  % switch adap 
       % case (1) % Performing all necessary steps for controls 
            % Mcake sure that folder actually exists. Warn  if it doesn't.
          %  if exist(myFolder1)
            %    errorMessage = sprintf...
             %   ('Error: The following folder does not exist:\n%s\nPlease specify a new folder.', myFolder1);
             %   uiwait(warndlg(errorMessage));
             %    myFolder1 = uigetdir(); % Ask for a new one.
            % if myFolder1 == 0
             %   return;
            % end
           % end
cd(myFolder1); % change current directory to myfolder 
filePattern = fullfile(myFolder1, '*.nii'); % find every niftii image in folder
scans = dir(filePattern); %safe fileinfo in structure

subjects = cell(1,27); % initiate cell structure for volumetric scans 

% if not already exist, create Folder for Normalized Images
            if not(exist('D:\Lenna\Versuch_1\scans\Subjects_norm'))
            mkdir('D:\Lenna\Versuch_1\scans\Subjects_norm'); %% muss hier ein  anderer Pfad sein als oben dr�ber
            end
%read volumetric niftii files in myfolder into a cell structure
            for i = 1 : length(scans)
            baseFileName = scans(i).name;
            fullFileName = fullfile(scans(i).folder, baseFileName);
            fprintf(1, 'Now reading %s\n', fullFileName);
            subjects{i} = spm_vol(baseFileName);
            end 
Gm_cont= readmatrix('D:\Lenna\Versuch_1\scripts\Globals.txt');
%Pfad f�r den output
       
            path= 'D:\Lenna\Versuch_1\scans\Subjects_norm';

%normalization via SPM's imCalc function 
            for i = 1: length(subjects)
                
                norm = Gm_cont(i);
                f = 'X/norm'; %define expression to use on images
                Vi = subjects{i}; %define input
                [~, fName, ext] = fileparts(subjects{i}.fname);  %% der Datei Pfad f�r subjects{i}.fname scheint nicht g�ltig zu sein
                Vo = fullfile(path,strcat(fName,'_GMnorm',ext)) ; %define output file names 
                flags = {1,1,1,16};
                spm_imcalc(Vi,Vo,f,flags,norm);
            end
            %add newly created folders to MATLAB path 
            addpath(path)
            %remove
  
       
    display('Intensity normalization of all subjects finished')
end
%end


