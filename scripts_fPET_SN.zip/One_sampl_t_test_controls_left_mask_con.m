% One-Sample-T-Test für Kontroll-Con-Maps
% Author L. Rüsing, adpted from K.Steidel, University Hospital of Gießen and Marburg
% Dieses Skript testet, ob die mittleren Con-Map-Werte der Kontrollgruppe signifikant von 0 abweichen.

clear; clc;

% Setze das Arbeitsverzeichnis (Passe `outdir` an dein Verzeichnis an)
[wdir, outdir] = Dynamicanalysis_defaults_V7;

% Definiere den Speicherort für den Test
one_sample_outputdir = fullfile(outdir, 'One_Sample_T_test_for_Controls_left_mask_con');

% Stelle sicher, dass das Ausgabeverzeichnis existiert
if ~exist(one_sample_outputdir, 'dir')
    mkdir(one_sample_outputdir);
end

% Lade alle Con-Maps der Kontrollgruppe mit angepasster Ordnerstruktur
allconmapscon = {
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_004', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_006', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_011', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_012', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_015', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_017', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_018', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_019', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_020', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_021', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_023', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_024', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_027', 'con_0001.nii')
};

% Führe den One-Sample-T-Test durch
perform_one_sample_t_test(allconmapscon, one_sample_outputdir);

% Ergebnisse anzeigen
showresults(one_sample_outputdir);

disp('One-Sample-T-Test für Kontrollen abgeschlossen.');
