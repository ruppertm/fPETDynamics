% One-Sample-T-Test für Patienten
% Author L. Rüsing, adpted from K.Steidel, University Hospital of Gießen and Marburg
% Dieses Skript testet, ob die mittleren Werte der Patientengruppe signifikant von 0 abweichen.

clear; clc;

% Setze das Arbeitsverzeichnis (Passe `outdir` an dein Verzeichnis an)
[wdir, outdir] = Dynamicanalysis_defaults_V7;

% Definiere den Speicherort für den Test
one_sample_outputdir = fullfile(outdir, 'One_Sample_T_test_for_Patients_left_mask_con');

% Stelle sicher, dass das Ausgabeverzeichnis existiert
if ~exist(one_sample_outputdir, 'dir')
    mkdir(one_sample_outputdir);
end

% Lade alle Patientennummern mit angepasster Ordnerstruktur
allpatientmaps = {
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_001', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_002', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_003', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_005', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_007', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_008', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_010', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_014', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_016', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_022', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_025', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_026', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_028', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_029', 'con_0001.nii')
};

% Führe den One-Sample-T-Test durch
perform_one_sample_t_test(allpatientmaps, one_sample_outputdir);

% Ergebnisse anzeigen
showresults(one_sample_outputdir);

disp('One-Sample-T-Test für Patienten abgeschlossen.');
