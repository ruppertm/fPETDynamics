%%% Dynamic voxel-wise second-level analysis
% Author L. Rüsing, adpted from K.Steidel, University Hospital of Gießen and Marburg
% General Settings
[wdir, outdir] = Dynamicanalysis_defaults_V7;


% General Settings to define new folders: subj = [first_level_pat... first_level_con...];
% Zweck: Die T-Maps aus der First-Level-Analyse  werden in Z-Maps umgewandelt, um statistische Vergleiche zwischen Gruppen zu ermöglichen.
firstlevelpat = {'first_level_001','first_level_002','first_level_003','first_level_005','first_level_007','first_level_008','first_level_010','first_level_014','first_level_016','first_level_022','first_level_025','first_level_026','first_level_028', 'first_level_029'};
firstlevelcon = {'first_level_004','first_level_006','first_level_011','first_level_012','first_level_015','first_level_017','first_level_018','first_level_019','first_level_020','first_level_021','first_level_023','first_level_024','first_level_027'};

% Loop through folders for T-maps of patients --> Umwandlung jeder T-Map in eine Z-Map und Speicherung im Ordner all_z_maps_patients
for i = 1:length(firstlevelpat)
    % Bestimmen des Pfads zur T-Map des aktuellen Patienten
    subjdirpat = fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', firstlevelpat{i}, 'spmT_0001');
    
    % Prüfen, ob die T-Map existiert, um Fehler zu vermeiden
    if ~exist([subjdirpat '.nii'], 'file')
        % Falls die Datei nicht existiert, wird eine Warnung ausgegeben und die Iteration übersprungen
        warning('Die Datei %s existiert nicht. Überspringe diese Iteration.', subjdirpat);
        continue;
    end
    
    % Bestimmen des Ausgabeordners für die Z-Map des aktuellen Patienten
    outputdirpat = fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'all_z_maps_patients', ['spmZ_' firstlevelpat{i}]);

    % Überprüfe, ob das Ausgabeverzeichnis existiert, andernfalls erstelle es
    if ~exist(outputdirpat, 'dir')
        mkdir(outputdirpat);  % Erstellt das Verzeichnis, wenn es nicht existiert
    end

    % Konvertiere T-Maps von Patienten in Z-Maps 
    % Die Funktion convert_spm_stat wird verwendet, um die T-Maps in Z-Maps umzuwandeln
    % Der dritte Parameter gibt den Freiheitsgrad (dof) an (z.B. 7 für eine typische Analyse)
    convert_spm_stat('TtoZ', subjdirpat, outputdirpat, '7');
end

% Loop through folders for T-maps of controls --> Umwandlung jeder T-Map in eine Z-Map und Speicherung im Ordner all_z_maps_controls
for i = 1:length(firstlevelcon)
    % Bestimmen des Pfads zur T-Map der aktuellen Kontrolle
    subjdircon = fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', firstlevelcon{i}, 'spmT_0001');
    
    % Prüfen, ob die T-Map existiert, um Fehler zu vermeiden
    if ~exist([subjdircon '.nii'], 'file')
        % Falls die Datei nicht existiert, wird eine Warnung ausgegeben und die Iteration übersprungen
        warning('Die Datei %s existiert nicht. Überspringe diese Iteration.', subjdircon);
        continue;
    end
    
    % Bestimmen des Ausgabeordners für die Z-Map der aktuellen Kontrolle
    outputdircon = fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'all_z_maps_controls', ['spmZ_' firstlevelcon{i}]);

    % Überprüfe, ob das Ausgabeverzeichnis existiert, andernfalls erstelle es
    if ~exist(outputdircon, 'dir')
        mkdir(outputdircon);  % Erstellt das Verzeichnis, wenn es nicht existiert
    end

    % Konvertiere T-Maps von Kontrollen in Z-Maps 
    % Die Funktion convert_spm_stat wird verwendet, um die T-Maps in Z-Maps umzuwandeln
    % Der dritte Parameter gibt den Freiheitsgrad (dof) an (z.B. 7 für eine typische Analyse)
    convert_spm_stat('TtoZ', subjdircon, outputdircon, '7');
end

% Two-sample t-test für Con-Maps der Patienten (Gruppe 1) und Kontrollen (Gruppe 2)
% Ziel: Vergleich der Con-Maps von Patienten- und Kontrollgruppe, um Unterschiede in der Hirnaktivität zu identifizieren.

% Verzeichnis für die Ergebnisse
lastoutputdir = fullfile(outdir, 'T_test_for_con-maps_SN_left_mask_con');

% Con-Maps der Patienten (Gruppe 1) - Ordnerstruktur für Patienten anpassen
allconpat = {
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_001', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_002', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_003', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_005', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_007', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_008', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_010', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_014', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_016', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_022', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_025', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_026', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_028', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_029', 'con_0001.nii')
};

% Con-Maps der Kontrollen (Gruppe 2) - Ordnerstruktur für Kontrollen anpassen
allconcon = {
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_004', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_006', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_011', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_012', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_015', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_017', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_018', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_019', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_020', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_021', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_023', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_024', 'con_0001.nii'),
    fullfile(outdir, 'Subjects_HC_gr_PD_fwe_SN_left_with_Mask', 'first_level_027', 'con_0001.nii')
};

% Durchführung des Two-Sample T-Tests
perform_two_sample_t_test(allconpat, allconcon, [-1 1], lastoutputdir);

% Ergebnisse anzeigen
showresults(lastoutputdir);