function roi_data = extract_roi_data(scan_files, roi)
% This function extracts ROI data from a set of subject scans using MarsBaR.
%
% Inputs:
% - subject_scans: a cell array of strings, where each string is the full file path of a subject scan
% - roi: a string specifying the full file path of the ROI file
%
% Output:
% - roi_data: a vector of ROI data extracted from the subject scans

% initialize marsbar toolbox
marsbar('on')

% Load ROI
roi_obj = maroi_image(struct('vol', spm_vol(roi), 'binarize',0,'func','img'));

% Initialize an empty cell array to hold the data
roi_data = {};

% Loop over the scan files
for i = 1:length(scan_files)
    % Load the scan
    V = spm_vol(scan_files{i});

    % Extract the ROI data from the scan
    data = getdata(roi_obj, V);

    % Append the mean cluster intensity to the cell array
    roi_data{i} = mean(data);
end

% convert to numeric cell array
roi_data         = cell2mat(roi_data);

% close marsbar toolbox
marsbar('off');

end