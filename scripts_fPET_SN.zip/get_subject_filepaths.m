function filepaths = get_subject_filepaths(directory, suffix)
    % Überprüfen, ob das Verzeichnis existiert
    if ~isfolder(directory)
        error('Das angegebene Verzeichnis existiert nicht: %s', directory);
    end
    
    % Der Rest der Funktion bleibt unverändert
    validateattributes(directory, {'char'}, {'nonempty'});

    % Definiere die Dateierweiterung für .nii Dateien
    ext = '.nii';

    % Hole eine Liste aller .nii Dateien im Verzeichnis
    files = dir(fullfile(directory, ['*', ext]));

    % Wenn ein Suffix angegeben ist, filtere nur Dateien, die diesen Suffix enthalten
    if nargin > 1 && ~isempty(suffix)
        files = files(contains({files.name}, suffix));
    end

    % Extrahiere die vollständigen Dateipfade
    filepaths = arrayfun(@(file) fullfile(directory, file.name), files, ...
                         'UniformOutput', false);
end