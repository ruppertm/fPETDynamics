function perform_one_sample_t_test(group_files, output_dir)
% This function performs a voxel-wise One-Sample-T-Test using SPM12.
%
% Inputs:
% - group_files: a cell array of file paths for Z-maps of a single group
% - output_dir: a string specifying the directory to save the output
%
% The test checks whether the mean of the group significantly differs from zero.

    % Check inputs
    assert(iscell(group_files), 'group_files must be a cell array of file paths');
    assert(ischar(output_dir), 'output_dir must be a string');

    % Initialize SPM
    spm('defaults', 'PET');
    spm_jobman('initcfg');

    % Specify output directory
    matlabbatch{1}.spm.stats.factorial_design.dir = {output_dir};

    % Set up the design matrix for a One-Sample-T-Test
    matlabbatch{1}.spm.stats.factorial_design.des.t1.scans = group_files;
    matlabbatch{1}.spm.stats.factorial_design.des.t1.gmsca = 0;
    matlabbatch{1}.spm.stats.factorial_design.des.t1.ancova = 0;
    matlabbatch{1}.spm.stats.factorial_design.cov = struct('c', {}, 'cname', {}, 'iCFI', {}, 'iCC', {});
    matlabbatch{1}.spm.stats.factorial_design.multi_cov = struct('files', {}, 'iCFI', {}, 'iCC', {});
    matlabbatch{1}.spm.stats.factorial_design.masking.tm.tm_none = 1;
    matlabbatch{1}.spm.stats.factorial_design.masking.im = 1;
    matlabbatch{1}.spm.stats.factorial_design.masking.em = {''};
    matlabbatch{1}.spm.stats.factorial_design.globalc.g_omit = 1;
    matlabbatch{1}.spm.stats.factorial_design.globalm.gmsca.gmsca_no = 1;
    matlabbatch{1}.spm.stats.factorial_design.globalm.glonorm = 1;

    % Estimate the model
    matlabbatch{2}.spm.stats.fmri_est.spmmat = {fullfile(output_dir, 'SPM.mat')};

    % Set up the contrast for the one-sample t-test (mean > 0)
    matlabbatch{3}.spm.stats.con.spmmat = {fullfile(output_dir, 'SPM.mat')};
    matlabbatch{3}.spm.stats.con.consess{1}.tcon.name = 'One-Sample T-Test';
    matlabbatch{3}.spm.stats.con.consess{1}.tcon.weights = 1;
    matlabbatch{3}.spm.stats.con.consess{1}.tcon.sessrep = 'none';

    % Run the job
    spm_jobman('run', matlabbatch);
end
