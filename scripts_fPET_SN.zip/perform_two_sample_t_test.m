function perform_two_sample_t_test(group_1_files, group_2_files, contrast, output_dir)
% This function performs a voxel-wise Multiple regression using SPM12..
%
% Inputs:
% - group_1_files: a cell array of file paths for Z-maps
% - group_2_files: a cell array of file paths for Z-maps
% - contrast: a vector of length 2 specifying the contrast for the t-test
% - output_dir: a string specifying the directory to save the output
%
% The contrast is used to set the weights for the Mutiple regression.
% Usually should be [0 1].
%
    % Check inputs
    assert(iscell(group_1_files), 'group1_files must be a cell array of file paths');
    assert(iscell(group_2_files), 'group2_files must be a cell array of file paths');
    assert(isvector(contrast) && length(contrast) == 2, 'contrast must be a vector of length 2');
    assert(ischar(output_dir), 'output_dir must be a string');

    % Initialize SPM
    spm('defaults', 'PET');
    spm_jobman('initcfg');
   
    % specify output directory
    matlabbatch{1}.spm.stats.factorial_design.dir = {output_dir};
   
    % Set up the design matrix for a two-sample t-test
    matlabbatch{1}.spm.stats.factorial_design.des.t2.scans1 = group_1_files; 
    matlabbatch{1}.spm.stats.factorial_design.des.t2.scans2 = group_2_files;
    matlabbatch{1}.spm.stats.factorial_design.des.t2.dept = 0;
    matlabbatch{1}.spm.stats.factorial_design.des.t2.variance = 1;
    matlabbatch{1}.spm.stats.factorial_design.des.t2.gmsca = 0;
    matlabbatch{1}.spm.stats.factorial_design.des.t2.ancova = 0;
    matlabbatch{1}.spm.stats.factorial_design.cov = struct('c', {}, 'cname', {}, 'iCFI', {}, 'iCC', {});
    matlabbatch{1}.spm.stats.factorial_design.multi_cov = struct('files', {}, 'iCFI', {}, 'iCC', {});
    matlabbatch{1}.spm.stats.factorial_design.masking.tm.tm_none = 1;
    matlabbatch{1}.spm.stats.factorial_design.masking.im = 1;
    matlabbatch{1}.spm.stats.factorial_design.masking.em = {''};
    matlabbatch{1}.spm.stats.factorial_design.globalc.g_omit = 1;
    matlabbatch{1}.spm.stats.factorial_design.globalm.gmsca.gmsca_no = 1;
    matlabbatch{1}.spm.stats.factorial_design.globalm.glonorm = 1;
    
    % Estimate the model
    matlabbatch{2}.spm.stats.fmri_est.spmmat = {fullfile(output_dir, 'SPM.mat')};

    % Set up the contrast for the t-test
    matlabbatch{3}.spm.stats.con.spmmat = {fullfile(output_dir, 'SPM.mat')};
    matlabbatch{3}.spm.stats.con.consess{1}.tcon.name = 'Mreg';
    matlabbatch{3}.spm.stats.con.consess{1}.tcon.weights = contrast;
    matlabbatch{3}.spm.stats.con.consess{1}.tcon.sessrep = 'none';

    % Run the job
    spm_jobman('run', matlabbatch);
end
